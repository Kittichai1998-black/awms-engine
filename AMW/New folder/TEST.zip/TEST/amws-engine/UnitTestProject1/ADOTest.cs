﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1
{
    [TestClass]
    public class ADOTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            var res = AWMSEngine.ADO.StorageObjectADO.GetInstant().GetStorageObjectByRelationCode("ST-S01-1/1/1");
            Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(res));
        }
    }
}
