﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWMSEngine.Engine.APIService.WM
{
    public class PutVirtualMapSTOAPI : BaseAPIService
    {
        protected override dynamic ExecuteEngineManual()
        {
            throw new NotImplementedException();
        }
    }
}
