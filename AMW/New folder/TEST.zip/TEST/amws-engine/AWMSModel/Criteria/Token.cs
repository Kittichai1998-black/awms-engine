﻿using AWMSModel.Constant.EnumConst;
using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Criteria
{
    public class amt_Token_status
    {
        public string token;
        public EntityStatus Status;
    }

    public class amt_Token_ext
    {
        public string token;
        public string extendKey;
    }
}
