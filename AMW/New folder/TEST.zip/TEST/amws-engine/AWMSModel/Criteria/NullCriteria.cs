﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Criteria
{
    public class NullCriteria
    {
        private NullCriteria() { }
    }
}
