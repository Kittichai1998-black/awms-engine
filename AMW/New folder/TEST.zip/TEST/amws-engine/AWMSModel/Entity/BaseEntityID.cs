﻿using AWMSModel.Constant.EnumConst;
using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public abstract class BaseEntityID : IEntityModel
    {
        public long? ID;
    }
}
