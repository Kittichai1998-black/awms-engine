﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public class ams_APIService : BaseEntitySTD
    {
    }
}
