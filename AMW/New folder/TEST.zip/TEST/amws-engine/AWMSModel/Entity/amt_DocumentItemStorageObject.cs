﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
   public  class amt_DocumentItemStorageObject : BaseEntityCreateOnly
    {
        public long DocumentItem_ID;
        public long StorageObject_ID;
    }
}
