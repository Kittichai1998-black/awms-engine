﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public class ams_BaseMaster : BaseEntitySTD
    {
        int BaseMasterType_ID;
        int ObjectSize_ID;
    }
}
