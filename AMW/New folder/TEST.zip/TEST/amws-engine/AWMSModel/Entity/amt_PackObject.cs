﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public class amt_PackObject : BaseEntitySTD
    {
    }
}
