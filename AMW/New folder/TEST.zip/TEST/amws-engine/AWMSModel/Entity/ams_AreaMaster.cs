﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public class ams_AreaMaster : BaseEntitySTD
    {
        public long? Warehouses_ID;
    }
}
