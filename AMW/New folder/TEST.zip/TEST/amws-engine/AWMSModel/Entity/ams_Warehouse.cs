﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Entity
{
    public class ams_Warehouse : BaseEntitySTD
    {
        public long? Branch_ID;
    }
}
