﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum VirtualMapSTOModeType
    {
        REGISTER = 0,
        TRANSFER
    }
}
