﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum StorageObjectType
    {
        LOCATION = 0,
        BASE = 1,
        PACK = 2
    }
}
