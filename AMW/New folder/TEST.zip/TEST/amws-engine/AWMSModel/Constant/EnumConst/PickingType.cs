﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum PickingType
    {
        BASEPICK = 1,
        PACKPICK = 2,
        //UNITPICK = 3,
    }
}
