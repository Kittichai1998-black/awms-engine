﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum LanguageType
    {
        TH = 0,
        EN = 1,
        CH = 2
    }
}
