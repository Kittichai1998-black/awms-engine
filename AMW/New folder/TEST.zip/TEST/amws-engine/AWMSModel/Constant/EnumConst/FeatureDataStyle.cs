﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum FeatureDataStyle
    {
        TEXT = 0,
        FLAG = 1,
        ARRAY = 2
    }
}
