﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum ConfigCode
    {
        /// <summary>Root Server สำหรับ API Transfer Master From File Server.</summary>
        APIFS_TRANS_MST_ROOTFILE,
    }
}
