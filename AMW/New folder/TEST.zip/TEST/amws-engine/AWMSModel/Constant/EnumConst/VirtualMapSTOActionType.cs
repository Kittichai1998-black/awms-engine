﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum VirtualMapSTOActionType
    {
        SELECT = 0,
        ADD = 1,
        REMOVE = 2
    }
}
