﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.EnumConst
{
    public enum EntityStatus
    {
        INACTIVE = 0,
        ACTIVE = 1,
        REMOVE = 2,
        DONE = 3
    }
}
