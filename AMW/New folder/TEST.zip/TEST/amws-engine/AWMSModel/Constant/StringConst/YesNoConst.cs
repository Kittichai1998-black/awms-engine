﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.StringConst
{
    public static class YesNoConst
    {
        public const string YES = "1";
        public const string NO = "0";
    }
}
