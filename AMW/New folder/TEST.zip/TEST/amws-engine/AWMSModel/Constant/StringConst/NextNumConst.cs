﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWMSModel.Constant.StringConst
{
    public static class NextNumConst
    {
        public const string DOC_RECEIVE = "DOC_RECEIVE";
    }
}
